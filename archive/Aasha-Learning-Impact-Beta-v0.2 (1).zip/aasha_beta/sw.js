const CACHE = 'aasha-beta-v0.2.0';
const CORE = [
  './','./index.html','./styles.css','./manifest.webmanifest','./src/app.js',
  './src/core/storage.js','./src/core/events.js','./src/core/teas.js','./src/core/rewards.js',
  './src/core/content-schema.js','./src/core/sync.js','./src/core/visuals.js','./src/core/asset-registry.js',
  './src/content/chapter.js'
];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(cached => cached || fetch(e.request).then(r => {
    const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return r;
  }).catch(() => caches.match('./index.html'))));
});
