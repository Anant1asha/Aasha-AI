# Changelog

## 0.2.0 — Beta architecture implementation

- Preserved Phase-0 Constitution v1.1 as authority.
- Broadened runtime/data model to Class 1–10 while retaining Class 6 Fractions as sample content.
- Added TLN-style learning node schema and dependency validation.
- Added universal question contract and deterministic TEAS mastery/progression separation.
- Added visual engine boundary and asset registry for licensed/open-source reuse.
- Added offline event log + asynchronous sync outbox.
- Added local learner identity and centre cohort metadata without mandatory login.
- Added reward ledger/idempotency with `manual_beta` verification status; reward kept low priority.
- Added automated structural/unit tests.
- Added AI governance boundary.
- Added PWA/service-worker offline shell.
- Added evidence export for pilot operations.
