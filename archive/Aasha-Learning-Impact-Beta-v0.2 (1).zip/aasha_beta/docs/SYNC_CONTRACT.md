# Aasha Async Sync Contract — Beta

Learning does not wait for connectivity.

## Local lifecycle

`interaction → event → local persistence → outbox → later sync`

## Batch request

```json
{
  "schema_version": 1,
  "device_session": "opaque-session-id",
  "events": [
    {
      "event_id": "EV-...",
      "event_type": "answer_submitted"
    }
  ]
}
```

## Server acknowledgement

The future sync endpoint should return acknowledged event IDs and any conflict records. The client removes only acknowledged IDs from the outbox.

## Required properties

- idempotent event ingestion
- replay protection through event IDs
- no destructive overwrite of learning evidence
- conflict records are explicit
- local learning remains usable during failed sync
- sync is eventually consistent, not progression-authoritative
