# Open-Source Asset + Simulation Policy

Use reuse-before-build as a standing engineering principle.

Each adopted asset must carry:

- asset_id
- source/project
- source_url
- license
- license_version/date where relevant
- attribution text
- version/commit
- adapter version
- offline status
- allowed modification/use status
- local fallback status
- validation status

Assets without a recorded license/provenance record are not promoted to production content.

An external simulation is wrapped behind a stable Aasha adapter so the chapter content does not depend on a vendor-specific API.
