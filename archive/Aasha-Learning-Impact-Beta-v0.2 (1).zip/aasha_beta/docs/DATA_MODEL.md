# Aasha Beta Data Model

## Learner
- `local_id`: device-local opaque identifier
- `display_name`: local display label
- `class_level`: integer 1–10
- `age_stage`: foundation (1–2), primary (3–5), middle (6–8), secondary (9–10)
- `cohort_code`: centre-assigned cohort reference

## Learning Node
- `node_id`
- `title`
- `objective`
- `dependencies[]`
- `steps[]`
- `asset_refs[]`
- `language layer`

## Event
- `event_id` (idempotency key)
- `schema_version`
- `event_type`
- `learner_ref`
- `session_id`
- `timestamp`
- `payload`

Events are append-oriented. Server sync should acknowledge event IDs rather than replacing the local event history.

## Assessment evidence
- question_id
- node_id
- result
- response_time_ms
- misconception tag

## Reward ledger
- ledger_id
- source_event_id
- coins_delta
- xp_delta
- verification_status
- verifier_ref (manual verification)
- timestamp

## Privacy principle
The learner runtime should retain only the minimum data needed for the pilot experience and evidence chain. Production identity, consent, retention and access policies belong in the platform/security layer, not inside chapter content.
