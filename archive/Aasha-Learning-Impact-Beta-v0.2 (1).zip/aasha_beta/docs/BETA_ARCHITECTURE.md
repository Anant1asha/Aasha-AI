# Annanth Aasha Foundation — Beta Architecture v0.2

**Authority:** Phase-0 Constitution v1.1 remains authoritative and is not modified by this package.
**Audience:** Class 1–10. The Beta content sample remains Class 6 only; the engine/data model is grade-agnostic across 1–10.

## Core authority chain

```text
School-book-derived content
        ↓
TLN / Learning Nodes
        ↓
Learning Runtime + Visual/Simulation adapters
        ↓
Question Contract
        ↓
Assessment evidence
        ↓
TEAS (deterministic progression authority)
        ↓
Reward Engine (low-priority Beta subsystem)
        ↓
Impact / Evidence reporting
        ↓
Async sync outbox
```

Game shells never calculate mastery. AI does not determine progression or reward authority.

## Offline model

Core learning works from local content and browser storage. Every material learner interaction emits an event. Events are retained locally and placed into an outbox. A future backend can acknowledge batches and resolve duplicates without changing the learner runtime.

## Identity

Learning does not require authentication. Beta uses a local learner identifier and centre cohort code. A production identity service may later associate that local record to a durable participant identity under explicit privacy rules.

## Visual and simulation boundary

Visual assets are typed assets. External/open-source simulations are not pasted directly into chapters: they enter through an asset registry carrying provenance, license, version, offline capability and adapter metadata.

## Content scalability

A chapter consists of immutable-ish versioned nodes, objectives, dependencies, steps, words, questions and asset references. New chapters supply data; they do not require new engine code.

## Reward scope in Beta

Reward infrastructure exists so the architecture does not need to be rebuilt later. In this Beta, reward verification is **manual** because participating children are from the centre. Reward logic must not affect learning progression and is not the top implementation priority.

## Measurement

The Beta distinguishes: presentation score, assessment accuracy, deterministic mastery, progression decision, reward ledger entry, and impact evidence. This prevents the common failure mode of using a game score as a learning metric.
