export function fractionVisual(total=5,active=3){
  return `<div class="fraction" role="img" aria-label="${active} of ${total} equal parts selected">${Array.from({length:total},(_,i)=>`<button class="part ${i<active?'on':''}" data-index="${i}" aria-label="Part ${i+1}"></button>`).join('')}</div>`;
}
export function renderVisual(type,data){
  if(type==='fraction')return fractionVisual(data.total,data.active);
  if(type==='bar')return `<div class="visual"><strong>${data.label||'Interactive model'}</strong><div class="progress"><i style="width:${Math.max(0,Math.min(100,data.percent||0))}%"></i></div></div>`;
  return `<div class="visual">${data?.label||'Visual learning asset'}</div>`;
}
