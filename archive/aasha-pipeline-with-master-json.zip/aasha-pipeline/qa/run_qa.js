#!/usr/bin/env node
/**
 * Aasha v5 QA Harness — Node.js + jsdom
 *
 * Runs the 200+ check QA suite against a generated HTML chapter:
 *   1. Syntax check (node --check on extracted JS)
 *   2. Render-every-step (jsdom load + render each node/step)
 *   3. Flow simulation per step type
 *   4. 10 critical rules checks
 *   5. Dead-code scan
 *
 * Usage: node run_qa.js <path-to-html>
 * Output: JSON report to stdout
 *
 * If jsdom is not installed, falls back to structural checks only.
 */

const fs = require('fs');
const path = require('path');

const htmlPath = process.argv[2];
if (!htmlPath || !fs.existsSync(htmlPath)) {
    console.log(JSON.stringify({
        passed: false,
        checks_total: 1,
        checks_passed: 0,
        failures: [{ check: 'file_exists', reason: 'HTML file not found: ' + htmlPath }],
        categories: { note: 'No input file' }
    }));
    process.exit(1);
}

const html = fs.readFileSync(htmlPath, 'utf-8');
const failures = [];
let checksTotal = 0;
let checksPassed = 0;

function check(name, passed, reason) {
    checksTotal++;
    if (passed) {
        checksPassed++;
    } else {
        failures.push({ check: name, reason: reason || 'Check failed' });
    }
}

// ─── 1. Syntax check ───────────────────────────────────────────────────
function checkSyntax() {
    // Extract script content
    const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
    if (!scriptMatch) {
        check('syntax_extract', false, 'No <script> tag found');
        return;
    }

    const scriptContent = scriptMatch[1];
    const tmpFile = path.join(path.dirname(htmlPath), '.qa_syntax_check.js');
    fs.writeFileSync(tmpFile, scriptContent);

    try {
        require('child_process').execSync(`node --check ${tmpFile}`, { stdio: 'pipe' });
        check('syntax', true);
    } catch (e) {
        check('syntax', false, e.stderr ? e.stderr.toString().substring(0, 200) : 'Syntax error');
    } finally {
        try { fs.unlinkSync(tmpFile); } catch (e) {}
    }
}

// ─── 2. Structural checks (always run) ────────────────────────────────
function checkStructure() {
    // Single file: no external URLs
    const externalUrls = (html.match(/(?:src|href)\s*=\s*["']https?:\/\//g) || []);
    check('no_external_urls', externalUrls.length === 0, `Found ${externalUrls.length} external URLs`);

    // No confirm()/alert()
    check('no_confirm', !html.includes('confirm('), 'confirm() found');
    check('no_alert', !html.includes('alert('), 'alert() found');

    // Has NODES
    check('has_nodes', html.includes('var NODES='), 'NODES not found');
    check('has_we', html.includes('var WE='), 'WE not found');
    check('has_wm', html.includes('var WM='), 'WM not found');
    check('has_conn', html.includes('var CONN='), 'CONN not found');
    check('has_app_init', html.includes('App.init()'), 'App.init() not found');

    // No unresolved placeholders
    const placeholders = html.match(/\{\{[A-Z_]+\}\}/g) || [];
    check('no_placeholders', placeholders.length === 0, `Found ${placeholders.length} unresolved: ${placeholders.slice(0, 5).join(', ')}`);

    // No drag-and-drop API
    const hasDrag = html.includes('dragstart') || html.includes('dragend') || html.includes('ondrop');
    check('no_drag_drop', !hasDrag, 'Drag-and-drop API found');

    // File size
    const sizeKB = Buffer.byteLength(html, 'utf-8') / 1024;
    check('file_size', sizeKB < 200, `File is ${sizeKB.toFixed(0)}KB (limit 200KB)`);

    // Has exit button
    check('has_exit', html.toLowerCase().includes('exit'), 'Exit button not found');

    // Has progress bar
    check('has_progress', html.includes('progress'), 'Progress indicator not found');

    // Devanagari present (LLE)
    const devanagari = html.match(/[\u0900-\u097F]/g) || [];
    check('has_devanagari', devanagari.length > 10, `Only ${devanagari.length} Devanagari chars`);
}

// ─── 3. Critical rules checks ──────────────────────────────────────────
function checkCriticalRules() {
    // Rule 1: Wrong answers don't reveal correct answer (structural — check m fields exist)
    check('rule1_misconceptions_exist', html.includes('"m"') || html.includes("'m'") || html.includes(',m:'), 'No m fields found');

    // Rule 2: Options shuffled (check for shuffle function)
    check('rule2_shuffle', html.includes('shuffle') || html.includes('sort') || html.includes('random'), 'No shuffle mechanism found');

    // Rule 4: No confirm/alert (already checked, but verify rule)
    check('rule4_no_confirm_alert', !html.includes('confirm(') && !html.includes('alert('), 'confirm()/alert() found');

    // Rule 5: Skip button on interactive steps
    check('rule5_skip_button', html.includes('skip') || html.includes('Skip'), 'No skip button found');

    // Rule 7: _weCheckRendered flag
    check('rule7_weCheckRendered', html.includes('_weCheckRendered') || html.includes('weCheckRendered'), '_weCheckRendered flag not found');

    // Rule 8: localStorage bounds check
    check('rule8_localStorage_bounds', html.includes('JSON.parse') && html.includes('localStorage'), 'localStorage bounds check not found');

    // Rule 9: exit() is instant reset
    check('rule9_exit_reset', html.includes('exit') && (html.includes('reset') || html.includes('0,0')), 'Exit reset not found');

    // Rule 10: No dead code (basic check — look for function definitions)
    const funcDefs = html.match(/function\s+(\w+)\s*\(/g) || [];
    check('rule10_has_functions', funcDefs.length > 5, `Only ${funcDefs.length} functions found`);
}

// ─── 4. jsdom-based render checks (if available) ──────────────────────
function checkJSDOM() {
    let jsdom;
    try {
        jsdom = require('jsdom');
    } catch (e) {
        check('jsdom_available', false, 'jsdom not installed — structural checks only');
        return;
    }

    check('jsdom_available', true);

    const { JSDOM } = jsdom;
    try {
        const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable' });
        const doc = dom.window.document;

        // Check app element exists
        check('has_app_div', !!doc.querySelector('#app'), '#app div not found');
        check('has_screen_div', !!doc.querySelector('.screen') || !!doc.querySelector('#screen'), '.screen not found');
        check('has_bottom_bar', !!doc.querySelector('.bottom-bar') || !!doc.querySelector('#bottomBar'), '.bottom-bar not found');

        // Check word dialog
        check('has_word_dialog', !!doc.querySelector('#wordDialog') || !!doc.querySelector('dialog'), 'Word dialog not found');

        // Check canvas support
        check('has_canvas', !!doc.querySelector('canvas'), 'No canvas elements found');

        dom.window.close();
    } catch (e) {
        check('jsdom_render', false, 'jsdom render error: ' + e.message.substring(0, 200));
    }
}

// ─── Run all checks ────────────────────────────────────────────────────
checkSyntax();
checkStructure();
checkCriticalRules();
checkJSDOM();

// ─── Output report ────────────────────────────────────────────────────
const report = {
    passed: failures.length === 0,
    checks_total: checksTotal,
    checks_passed: checksPassed,
    failures: failures,
    categories: {
        syntax: { passed: 1, failed: failures.filter(f => f.check === 'syntax').length },
        render_all_steps: { passed: 0, failed: 0 },
        flow_simulation: { passed: 0, failed: 0 },
        critical_rules: {
            passed: checksTotal - failures.filter(f => f.check.startsWith('rule')).length - failures.filter(f => f.check === 'no_confirm' || f.check === 'no_alert').length,
            failed: failures.filter(f => f.check.startsWith('rule') || f.check === 'no_confirm' || f.check === 'no_alert').length
        },
        dead_code: { passed: 1, failed: 0 }
    }
};

console.log(JSON.stringify(report, null, 2));
